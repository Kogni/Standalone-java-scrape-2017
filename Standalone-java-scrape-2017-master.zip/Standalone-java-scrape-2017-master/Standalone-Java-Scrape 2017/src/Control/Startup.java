package Control;

public class Startup {

	public static void main(String[] args) {
		Control class_Control = new Control();
	}

}
