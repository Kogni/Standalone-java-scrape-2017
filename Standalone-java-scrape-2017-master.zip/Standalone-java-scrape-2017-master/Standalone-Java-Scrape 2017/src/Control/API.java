package Control;

import java.net.URL;

import Objects.Object_Product;

public class API {

    Control class_control;

    public API(Control class_control) {
	this.class_control = class_control;
    }

    public URL get_URL_to_check() {
	return null;
    }

    public void generate_product_description() {

    }

    public void get_product_images() {

    }

    public void get_meta_tag_title() {

    }

    public void get_Meta_Tag_Description() {

    }

    public void get_Meta_Tag_Keywords() {

    }

    public void get_Product_Tags() {

    }

    public void get_location() {

    }

    public void get_price() {

    }

    public void generate_model() {

    }

    public String generate_prouct_name() {
	return "test product name";
    }

    public void set_price_NOK() {

    }

    public void set_quantity() {

    }

    public void set_substract_Stock() {

    }

    public void set_stock_status() {

    }

    public void set_SEO_URL() {

    }

    public void set_status() {

    }

    public void set_sort_order() {

    }

    public void set_categories() {

    }

    public void set_attributes() {

    }

    public void set_attribute_materials() {

    }

    public void set_attribute_stoerrelser() {

    }

    public void set_attribute_antall() {

    }

    public void set_attribute_maletilstand() {

    }

    public void set_attribute_scales() {

    }

    public void set_image_featured() {

    }

    public void set_image_2() {

    }

    public void set_image_3() {

    }

    public void set_source(URL target) {
	class_control.aktivt_produkt.set_source(target);
    }

    public void set_product_name(String prouct_name) {
	class_control.aktivt_produkt.set_product_name(prouct_name);
    }
}
