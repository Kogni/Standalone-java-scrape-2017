package GUI;

import javax.swing.JFrame;

public class Frame_Main extends JFrame {

}
